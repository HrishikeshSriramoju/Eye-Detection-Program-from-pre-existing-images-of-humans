globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_57d40746._.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_a9cb0712.js",
    "static/chunks/node_modules_next_dist_compiled_5150ccfd._.js",
    "static/chunks/node_modules_next_dist_client_cf1d9188._.js",
    "static/chunks/node_modules_next_dist_b0daae9a._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_b3dc30d6._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_cdba956c._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];