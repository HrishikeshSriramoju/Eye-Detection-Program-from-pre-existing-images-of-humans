(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_01d5bd0f._.js",
  "static/chunks/src_5a23dcea._.js"
],
    source: "dynamic"
});
