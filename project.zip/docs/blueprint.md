# **App Name**: EyeDetect

## Core Features:

- Image Upload: Allow users to upload an image of an eye.
- Eye Color Detection: Use AI to identify the eye color from the uploaded image (Brown/Black, Blue, Green/Hazel, Amber/Yellow, Red/Pink).
- Genetic Trait Display: Display the genetic trait associated with the detected eye color, extracted by using OCR as a tool to identify the eye colors' genetic explanation from the prompt images provided.
- Result Display: Display the detected eye color and its corresponding genetic trait in a clear and concise manner.

## Style Guidelines:

- Primary color: Deep teal (#008080) to evoke a sense of clarity and focus.
- Background color: Light grayish-teal (#E0EEEE) to complement the primary color.
- Accent color: Soft amber (#FFC107) to highlight important information.
- Body and headline font: 'Inter', a grotesque-style sans-serif with a modern, machined, objective, neutral look; suitable for headlines or body text.
- Use simple and scientific icons for image upload and result display.
- Subtle animations when processing the image and displaying results.