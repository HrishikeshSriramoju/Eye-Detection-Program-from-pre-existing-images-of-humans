import { Dna } from 'lucide-react';

export function AppHeader() {
  return (
    <header className="p-4 border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto flex items-center gap-3">
        <div className="p-2 bg-primary rounded-md">
            <Dna className="text-primary-foreground" />
        </div>
        <h1 className="text-2xl font-bold font-headline text-primary">EyeDetect</h1>
      </div>
    </header>
  );
}
