"use client";

import { useState } from "react";
import Image from "next/image";
import { UploadCloud, Loader2, Eye, Dna, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { detectEyeColorAndGeneticTrait } from "@/ai/flows/detect-eye-color-and-genetic-trait";
import type { DetectEyeColorAndGeneticTraitOutput } from "@/ai/flows/detect-eye-color-and-genetic-trait";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function EyeDetector() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [result, setResult] = useState<DetectEyeColorAndGeneticTraitOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();

  const handleFileChange = (file: File | null) => {
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    } else {
      toast({
        variant: "destructive",
        title: "Invalid File",
        description: "Please upload an image file.",
      });
    }
  };

  const handleDragEvents = (e: React.DragEvent<HTMLLabelElement>, isEntering: boolean) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(isEntering);
  };

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    handleDragEvents(e, false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files[0]);
      e.dataTransfer.clearData();
    }
  };
  
  const handleSubmit = async () => {
    if (!imagePreview) return;
    setIsLoading(true);
    try {
      const response = await detectEyeColorAndGeneticTrait({ eyeImageDataUri: imagePreview });
      setResult(response);
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Analysis Failed",
        description: "Could not analyze the image. Please try another one.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleReset = () => {
    setImagePreview(null);
    setResult(null);
    setIsLoading(false);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-8">
      <Card className="text-center transition-all duration-300">
        <CardHeader>
          <CardTitle className="text-xl font-headline">Upload an Image of an Eye</CardTitle>
        </CardHeader>
        <CardContent>
          <input
            type="file"
            id="eye-image-upload"
            className="hidden"
            accept="image/*"
            onChange={(e) => handleFileChange(e.target.files ? e.target.files[0] : null)}
            disabled={isLoading}
          />
          <label
            htmlFor="eye-image-upload"
            onDragEnter={(e) => handleDragEvents(e, true)}
            onDragLeave={(e) => handleDragEvents(e, false)}
            onDragOver={(e) => handleDragEvents(e, true)}
            onDrop={handleDrop}
            className={`flex justify-center items-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
              isDragging ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/50'
            } ${imagePreview ? 'p-2' : 'p-10'}`}
          >
            {imagePreview ? (
              <div className="relative w-full h-full">
                <Image src={imagePreview} alt="Eye preview" fill className="object-contain rounded-md" />
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <UploadCloud className="w-12 h-12" />
                <p className="font-semibold">Click to upload or drag and drop</p>
                <p className="text-sm">PNG, JPG, or WEBP</p>
              </div>
            )}
          </label>
          
          <div className="mt-6 flex justify-center gap-4">
            <Button onClick={handleSubmit} disabled={!imagePreview || isLoading} size="lg">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                "Detect Color & Trait"
              )}
            </Button>
            { (imagePreview || result) && (
                <Button onClick={handleReset} variant="outline" size="lg" disabled={isLoading}>
                    <RefreshCw className="h-4 w-4" />
                </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {result && !isLoading && (
        <div className="animate-in fade-in-50 zoom-in-95 duration-500">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-xl font-headline">
                        Analysis Results
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 text-base">
                    <div className="flex items-start gap-4">
                        <div className="p-2 bg-primary/10 rounded-full flex-shrink-0">
                            <Eye className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-muted-foreground">Eye Color</h3>
                            <p className="text-lg font-bold text-primary">{result.eyeColor}</p>
                        </div>
                    </div>
                    <div className="flex items-start gap-4">
                         <div className="p-2 bg-primary/10 rounded-full flex-shrink-0">
                            <Dna className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                            <h3 className="font-semibold text-muted-foreground">Genetic Trait</h3>
                            <p className="leading-relaxed">{result.geneticTrait}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
      )}
    </div>
  );
}
