import { AppHeader } from '@/components/app-header';
import { EyeDetector } from '@/components/eye-detector';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <AppHeader />
      <main className="flex-1 container mx-auto p-4 md:p-8 flex items-center justify-center">
        <EyeDetector />
      </main>
    </div>
  );
}
