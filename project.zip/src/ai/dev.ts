import { config } from 'dotenv';
config();

import '@/ai/flows/detect-eye-color-and-genetic-trait.ts';