'use server';

/**
 * @fileOverview Detects the eye color from an image and displays the associated genetic trait.
 *
 * - detectEyeColorAndGeneticTrait - A function that handles the eye color detection and genetic trait retrieval process.
 * - DetectEyeColorAndGeneticTraitInput - The input type for the detectEyeColorAndGeneticTrait function.
 * - DetectEyeColorAndGeneticTraitOutput - The return type for the detectEyeColorAndGeneticTrait function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DetectEyeColorAndGeneticTraitInputSchema = z.object({
  eyeImageDataUri: z
    .string()
    .describe(
      "A photo of an eye, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type DetectEyeColorAndGeneticTraitInput = z.infer<typeof DetectEyeColorAndGeneticTraitInputSchema>;

const DetectEyeColorAndGeneticTraitOutputSchema = z.object({
  eyeColor: z.string().describe('The detected eye color (e.g., Brown, Blue, Green, Hazel, Amber, Red).'),
  geneticTrait: z.string().describe('The genetic trait associated with the detected eye color.'),
});
export type DetectEyeColorAndGeneticTraitOutput = z.infer<typeof DetectEyeColorAndGeneticTraitOutputSchema>;

export async function detectEyeColorAndGeneticTrait(
  input: DetectEyeColorAndGeneticTraitInput
): Promise<DetectEyeColorAndGeneticTraitOutput> {
  return detectEyeColorAndGeneticTraitFlow(input);
}

const detectEyeColorAndGeneticTraitPrompt = ai.definePrompt({
  name: 'detectEyeColorAndGeneticTraitPrompt',
  input: {schema: DetectEyeColorAndGeneticTraitInputSchema},
  output: {schema: DetectEyeColorAndGeneticTraitOutputSchema},
  prompt: `You are an expert in eye color detection and genetics.

  Analyze the provided image of an eye and identify its color. Possible eye colors include: Brown/Black, Blue, Green/Hazel, Amber/Yellow, Red/Pink.
  Based on the detected eye color, provide the corresponding genetic trait associated with that color. Use the media to analyze the image and base your conclusions about the
  eye color solely on the media provided. Use the following format:

  Eye Color: [Detected Eye Color]
  Genetic Trait: [Explanation of the genetic trait associated with the eye color]

  Image: {{media url=eyeImageDataUri}}
  `,
});

const detectEyeColorAndGeneticTraitFlow = ai.defineFlow(
  {
    name: 'detectEyeColorAndGeneticTraitFlow',
    inputSchema: DetectEyeColorAndGeneticTraitInputSchema,
    outputSchema: DetectEyeColorAndGeneticTraitOutputSchema,
  },
  async input => {
    const {output} = await detectEyeColorAndGeneticTraitPrompt(input);
    return output!;
  }
);
